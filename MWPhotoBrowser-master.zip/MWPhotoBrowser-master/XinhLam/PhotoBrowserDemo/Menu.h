//
//  Menu.h
//  MWPhotoBrowser
//
//  Created by Michael Waterfall on 21/10/2010.
//  Copyright 2010 d3i. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MWPhotoBrowser.h"
#import <AssetsLibrary/AssetsLibrary.h>

#define hayLamBaseURL @"http://haylam.vn"
#define msgConnectionError @"Không kết nối được tới máy chủ. Vui lòng kiểm tra lại kết nối mạng"
#define msgDataError @"Không lấy được dữ liệu từ máy chủ. Vui lòng thử lại hoặc liên hệ với chúng tôi để được hỗ trợ"
#define msgDataParseError @"Không xử lý được dữ liệu từ máy chủ. Vui lòng thử lại hoặc liên hệ với chúng tôi để được hỗ trợ"

#define notificationMsgNewData @"Many photos of beautiful girls have been updated."


#define hayLamDataURLDef @"http://haylam.vn/xinhlam/ActionHandler.ashx?ActionObject=examination&action=getListImageByPage&currentPage=0&pageSize=30&categoryId=1&orderBy=new"

#define hayLamDataURL @"http://haylam.vn/ActionHandler.ashx"
#define xinhLamDataURL @"http://haylam.vn/xinhlam/ActionHandler.ashx"

#define hayLamTitle  @"Gái xinh"

#define hayLamPhotoFilterNumber 3

#define hayLamPhotoPageSize 30

#define notificationSecondToFire 5

@interface Menu : UITableViewController <MWPhotoBrowserDelegate> {
    UISegmentedControl *_segmentedControl;
    NSMutableArray *_selections;
}

@property (nonatomic, strong) NSMutableArray *photos;
@property (nonatomic, strong) NSMutableArray *thumbs;
@property (nonatomic, strong) ALAssetsLibrary *assetLibrary;
@property (nonatomic, strong) NSMutableArray *assets;
- (void)loadAssets;

@end
