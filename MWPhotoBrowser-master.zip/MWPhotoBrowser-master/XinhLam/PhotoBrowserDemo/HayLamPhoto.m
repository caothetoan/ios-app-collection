//
//  HayLamPhoto.m
//  XinhLam
//
//  Created by Toan Cao on 8/23/14.
//
//

#import "HayLamPhoto.h"
#import "HayLamHelper.h"

#define hayLamBaseURL @"http://haylam.vn/"

#define hayLamDataURL @"http://haylam.vn/xinhlam/ActionHandler.ashx?ActionObject=examination&action=getListImageByPage"
#define hayLamAPIKey @"2ac7d4cad43cc859031badbb5bef9d01"

#define hayLamParamMethod @"action"
#define hayLamParamAppKey @"api_key"
#define hayLamParamUsername @"username"
#define hayLamParamUserid @"user_id"
#define hayLamParamPhotoSetId @"photoset_id"

#define hayLamParamPhotoCategoryId @"categoryId"
#define hayLamParamPhotoOrderBy @"orderBy"
#define hayLamParamPhotoPageSize @"pageSize"
#define hayLamParamPhotoCurrentPage @"currentPage"

#define hayLamParamExtras @"extras"

#define hayLamMethodFindByUsername @"getListImageByUsername"
#define hayLamMethodGetPhotoSetList @"getListImageByPage"

@implementation HayLamPhoto

@end

