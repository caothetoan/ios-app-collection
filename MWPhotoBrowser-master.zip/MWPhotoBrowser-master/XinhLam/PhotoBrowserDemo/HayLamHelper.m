//
//  WebServiceClient.m
//  Gai xinh
//
//  Created by Cao The Toan on 26/08/14.
//  Copyright 2014 HayLam.vn.
//

#import "HayLamHelper.h"

#define hayLamBaseURL @"http://haylam.vn/"

#define hayLamDataURL @"http://haylam.vn/xinhlam/ActionHandler.ashx"

#define hayLamAPIKey @"2ac7d4cad43cc859031badbb5bef9d01"

#define hayLamParamMethod @"action"
#define hayLamParamAppKey @"api_key"
#define hayLamParamUsername @"username"
#define hayLamParamUserid @"userId"
#define hayLamParamPhotoSetId @"photoId"

#define hayLamParamPhotoCategoryId @"categoryId"
#define hayLamParamPhotoOrderBy @"orderBy"
#define hayLamParamPhotoPageSize @"pageSize"
#define hayLamParamPhotoCurrentPage @"currentPage"

#define hayLamParamExtras @"extras"

#define hayLamMethodFindByUsername @"getListImageByUsername"
#define hayLamMethodGetPhotoSetList @"getListImageByPage"
@implementation HayLamHelper
+ (NSURL *)buildURLWithParameters:(int )categoryId :(int )pageIndex :(int )pageSize :(NSString *) orderby
{
    
    NSString *URLString =     [NSString stringWithFormat:@"%@?ActionObject=examination&action=getListImageByPage&categoryId=%d&currentPage=%d&pageSize=%d&orderBy=%@", hayLamDataURL, categoryId, pageIndex, pageSize, orderby];
    
    NSURL *URL = [NSURL URLWithString:URLString];
    return URL;
}
+ (NSData *)fetchResponseWithURL:(NSURL *)URL
{
   NSURLRequest *request = [NSURLRequest requestWithURL:URL];
   NSURLResponse *response = nil;
   NSError *error = nil;
   NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
   return data;
}
+ (NSURL *)buildURLWithParameters:(NSDictionary *)parameters
{
    NSMutableString *URLString = [[NSMutableString alloc] initWithString:hayLamDataURL];
    for (id key in parameters) {
        NSString *value = [parameters objectForKey:key];
        [URLString appendFormat:@"%@=%@&", key, [value stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    NSURL *URL = [NSURL URLWithString:URLString];
    return URL;
}

+ (id)getJSONSWithParameters:(NSDictionary *)parameters
{
    NSURL *URL = [self buildURLWithParameters:parameters];
    NSData *data = [HayLamHelper fetchResponseWithURL:URL];
    NSError *myError = nil;
    
    NSDictionary *res = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&myError];
    
    
    return res;
}
+ (NSDictionary *)photoGetListWithParam:(int )categoryId :(int )pageIndex :(int )pageSize :(NSString *) orderby
{
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:hayLamMethodGetPhotoSetList, hayLamParamMethod, hayLamAPIKey, hayLamParamAppKey, categoryId, hayLamParamPhotoCategoryId,pageIndex, hayLamParamPhotoCurrentPage, pageSize, hayLamParamPhotoPageSize,orderby, hayLamParamPhotoOrderBy, nil];
    NSDictionary *json = [self getJSONSWithParameters:parameters];
    
    return json;
}
@end
