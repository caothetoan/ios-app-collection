//
//  Menu.m
//  GaiXinh.HayLam.vn
//
//  Created by Cao The Toan on 25/08/2014.
//  Using MWPhotoBrowser lib
//  Copyright (c) 2014 HayLam.vn. All rights reserved.
//

#import "Menu.h"
#import "SDImageCache.h"
#import "MWCommon.h"

#import "Reachability.h"
#import <SystemConfiguration/SystemConfiguration.h>

#import "HayLamHelper.h"


@interface Menu ()
@property (nonatomic) Reachability *hostReachability;
@property (nonatomic) Reachability *internetReachability;
@property (nonatomic) Reachability *wifiReachability;

@property (nonatomic, strong) NSMutableData *responseData;

@property (nonatomic, strong) MWPhotoBrowser *mwPhotoBrowser;

@property (nonatomic) NSIndexPath *indexPath;
@property (nonatomic) int categoryId;
@property (nonatomic) int pageIndex;
@property (nonatomic) int pageSize;
@property (nonatomic) int pageTotal;
@property (nonatomic) NSString *orderby;

@end

@implementation Menu

@synthesize responseData = _responseData;
// Add this to the interface in the .m file of your view controller
- (BOOL)connected
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
}
-(void) alertMessage:(NSString *) message{
    UIAlertView * alert =[[UIAlertView alloc ] initWithTitle:@"Connection error"
                                                     message:message
                                                    delegate:self
                                           cancelButtonTitle:@"Try again"
                                           otherButtonTitles: nil];
  
    [alert show];
}
-(void) alertView:(NSString *) title :(NSString *) message{
    UIAlertView * alert =[[UIAlertView alloc ] initWithTitle:title
                                                     message:message
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles: @"Ok", nil];
    //[alert addButtonWithTitle:@"Ok"];
    [alert show];
}

#pragma mark -
#pragma mark Initialization

- (id)initWithStyle:(UITableViewStyle)style {
    if ((self = [super initWithStyle:style])) {
		self.title = hayLamTitle;
        
        // Clear cache for testing
        //[[SDImageCache sharedImageCache] clearDisk];
        //[[SDImageCache sharedImageCache] clearMemory];
        
        _segmentedControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Push", @"Modal", nil]];
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
        if (SYSTEM_VERSION_LESS_THAN(@"7")) {
            _segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
        }
#endif
        _segmentedControl.selectedSegmentIndex = 0;
        [_segmentedControl addTarget:self action:@selector(segmentChange) forControlEvents:UIControlEventValueChanged];
        
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:_segmentedControl];
        self.navigationItem.rightBarButtonItem = item;
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Menu" style:UIBarButtonItemStyleBordered target:nil action:nil];

        //[self loadAssets];
        
    }
    return self;
}

- (void)segmentChange {
    [self.tableView reloadData];
}


#pragma mark -
#pragma mark View

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Test toolbar hiding
//    [self setToolbarItems: @[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:nil action:nil]]];
//    [[self navigationController] setToolbarHidden:NO animated:NO];
    
    NSLog(@"viewdidload");
    
    if (![self connected]) {
        // not connected
        [self alertMessage:msgConnectionError];
        NSLog(msgConnectionError);
        return;
    } else {
        // connected, do some internet stuff
        
        self.responseData = [NSMutableData data];
        //self.indexPath =[NSIndexPath init];
        
        self.pageIndex = 0;
        self.pageSize = hayLamPhotoPageSize;
        self.categoryId = 0;
        self.orderby = @"new";
        
        NSString *URLString =     [NSString stringWithFormat:@"%@?ActionObject=examination&action=getListImageByPage&categoryId=%d&currentPage=%d&pageSize=%d&orderBy=%@", xinhLamDataURL, self.categoryId, self.pageIndex, hayLamPhotoPageSize, self.orderby ];
        
        
        NSURLRequest *request = [NSURLRequest requestWithURL:
                                 [NSURL URLWithString:URLString]];
        //NSURLConnection *connection =
        [[NSURLConnection alloc] initWithRequest:request delegate:self];
        
    }
  }


/*!
 * Called by Reachability whenever status changes.
 */
- (void) reachabilityChanged:(NSNotification *)note
{
	Reachability* curReach = [note object];
	NSParameterAssert([curReach isKindOfClass:[Reachability class]]);
	[self updateInterfaceWithReachability:curReach];
}


- (void)updateInterfaceWithReachability:(Reachability *)reachability
{
    if (reachability == self.hostReachability)
	{
		
        //NetworkStatus netStatus = [reachability currentReachabilityStatus];
        
    
        BOOL connectionRequired = [reachability connectionRequired];
        
      
        NSString* baseLabelText = @"";
        
        if (connectionRequired)
        {
            baseLabelText = NSLocalizedString(@"Cellular data network is available.\nInternet traffic will be routed through it after a connection is established.", @"Reachability text if a connection is required");
        }
        else
        {
            baseLabelText = NSLocalizedString(@"Cellular data network is active.\nInternet traffic will be routed through it.", @"Reachability text if a connection is not required");
        }
       //NSLog( baseLabelText);
    }
    
	if (reachability == self.internetReachability)
	{
		
	}
    
	if (reachability == self.wifiReachability)
	{
		
	}
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kReachabilityChangedNotification object:nil];
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSLog(@"didReceiveResponse");
    [self.responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"didFailWithError");
    NSLog([NSString stringWithFormat:@"Connection failed: %@", [error description]]);
   
    [self alertMessage:msgConnectionError];
    NSLog(msgConnectionError);
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSLog(@"connectionDidFinishLoading");
    if(self.responseData == nil){
        [self alertMessage:msgDataError];
        return;
    }
    unsigned long responseDataLength = (unsigned long)[self.responseData length];
    if(responseDataLength <= 0)
    {
     // alert message
        [self alertMessage:msgDataError];
        return;
    }
    NSLog(@"Succeeded! Received %lu bytes of data",(unsigned long)[self.responseData length]);
    
    // convert to JSON
    NSError *myError = nil;
    NSDictionary *res = [NSJSONSerialization JSONObjectWithData:self.responseData options:NSJSONReadingMutableLeaves error:&myError];
    if(res== nil){
        [self alertMessage:msgDataParseError];
        return;
    }
    //NSLog(@"res: %@", res);
    // show all values
   //NSMutableArray *haylamPhotoArray = [[NSMutableArray alloc] init];
    
    // extract specific value...
   // NSArray *results = [res objectForKey:@"ImageSrc"];
    NSLog(@"Count %lu", (unsigned long)res.count);
    self.pageTotal =5;
    //
	// Browser
	NSMutableArray *photos = [[NSMutableArray alloc] init];
	NSMutableArray *thumbs = [[NSMutableArray alloc] init];
    MWPhoto *photo;
    BOOL displayActionButton = YES;
    BOOL displaySelectionButtons = NO;
    BOOL displayNavArrows = YES;
    BOOL enableGrid = YES;
    BOOL startOnGrid = YES;
    
    // add object to mwphoto
    for (NSDictionary *result in res) {
        NSString *src = [result objectForKey:@"ImageSrc"];
        //NSLog(@"ImageSrc: %@", src);
        NSString *desc = [result objectForKey:@"Description"];
        
        photo = [MWPhoto photoWithURL:[NSURL URLWithString:src]];
        photo.caption = desc;
        [photos addObject:photo];
        [thumbs addObject:[MWPhoto photoWithURL:[NSURL URLWithString:src]]];
      
    }//end for
  
    self.photos = photos;
    self.thumbs = thumbs;
	
	// Create browser
    
    self.mwPhotoBrowser =  [[MWPhotoBrowser alloc] initWithDelegate:self];
    
	//MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
   
    self.mwPhotoBrowser.displayActionButton = displayActionButton;
    self.mwPhotoBrowser.displayNavArrows = displayNavArrows;
    self.mwPhotoBrowser.displaySelectionButtons = displaySelectionButtons;
    self.mwPhotoBrowser.alwaysShowControls = displaySelectionButtons;
    self.mwPhotoBrowser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    self.mwPhotoBrowser.wantsFullScreenLayout = YES;
#endif
    self.mwPhotoBrowser.enableGrid = enableGrid;
    self.mwPhotoBrowser.startOnGrid = startOnGrid;
    self.mwPhotoBrowser.enableSwipeToDismiss = YES;
    [self.mwPhotoBrowser setCurrentPhotoIndex:0];
    
    // Reset selections
    if (displaySelectionButtons) {
        _selections = [NSMutableArray new];
        for (int i = 0; i < photos.count; i++) {
            [_selections addObject:[NSNumber numberWithBool:NO]];
        }
    }
    
    // Show
    if (_segmentedControl.selectedSegmentIndex == 0) {
        // Push
        [self.navigationController pushViewController:self.mwPhotoBrowser animated:YES];
    } else {
        // Modal
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:self.mwPhotoBrowser];
        nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:nc animated:YES completion:nil];
    }
    
    // Release
	//(NSIndexPath *)indexPath ;
	// Deselect
	//[self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // Test reloading of data after delay
    //double delayInSeconds = 3;
   // dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
   // dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
        //        // Test removing an object
        //        [_photos removeLastObject];
        //        [browser reloadData];
        //
        //        // Test all new
        //        [_photos removeAllObjects];
        //        [_photos addObject:[MWPhoto photoWithFilePath:[[NSBundle mainBundle] pathForResource:@"photo3" ofType:@"jpg"]]];
        //        [browser reloadData];
        //
        //        // Test changing photo index
        //        [browser setCurrentPhotoIndex:9];
        
        //        // Test updating selections
        //        _selections = [NSMutableArray new];
        //        for (int i = 0; i < [self numberOfPhotosInPhotoBrowser:browser]; i++) {
        //            [_selections addObject:[NSNumber numberWithBool:YES]];
        //        }
        //        [browser reloadData];
        
   // });
}

- (void)viewDidUnload {
    [super viewDidUnload];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    self.navigationController.navigationBar.barTintColor = [UIColor greenColor];
//    self.navigationController.navigationBar.translucent = NO;
//    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    // set up local notifications
    [self setupLocalNotifications];
}

// push notification
//This basically setup a local notification to fire 5 seconds in the future from when the app view comes on screen.
- (void)setupLocalNotifications {
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
    
    // current time plus 10 secs
    NSDate *now = [NSDate date];
    NSDate *dateToFire = [now dateByAddingTimeInterval:notificationSecondToFire];
    
    NSLog(@"now time: %@", now);
    NSLog(@"fire time: %@", dateToFire);
    
    localNotification.fireDate = dateToFire;
    localNotification.alertBody = notificationMsgNewData;
    localNotification.soundName = UILocalNotificationDefaultSoundName;
    localNotification.applicationIconBadgeNumber = 1; // increment
    
    NSDictionary *infoDict = [NSDictionary dictionaryWithObjectsAndKeys:@"Object 1", @"Key 1", @"Object 2", @"Key 2", nil];
    localNotification.userInfo = infoDict;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}
// push notification
//This basically setup a local notification to fire 5 seconds in the future from when the app view comes on screen.
- (void)pushLocalNotifications:(int )secondFireDate :(NSString *) alertBody
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
    
    // current time plus 10 secs
    NSDate *now = [NSDate date];
    NSDate *dateToFire = [now dateByAddingTimeInterval:secondFireDate];
    
    NSLog(@"now time: %@", now);
    NSLog(@"fire time: %@", dateToFire);
    
    localNotification.fireDate = dateToFire;
    localNotification.alertBody = alertBody;
    localNotification.soundName = UILocalNotificationDefaultSoundName;
    localNotification.applicationIconBadgeNumber = 1; // increment
    
    NSDictionary *infoDict = [NSDictionary dictionaryWithObjectsAndKeys:@"Object 1", @"Key 1", @"Object 2", @"Key 2", nil];
    localNotification.userInfo = infoDict;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}
// thoat ung dung
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
//    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationNone;
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rows = hayLamPhotoFilterNumber;
    @synchronized(_assets) {
        if (_assets.count) rows++;
    }
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	// Create
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    cell.accessoryType = _segmentedControl.selectedSegmentIndex == 0 ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;

    // Configure
	switch (indexPath.row) {
		case 0: {
            cell.textLabel.text = @"Ảnh Mới";
            cell.detailTextLabel.text = @"Ảnh Gái xinh mới nhất";
            break;
        }
		case 1: {
            cell.textLabel.text = @"18+";
            cell.detailTextLabel.text = @"Ảnh Hot 18+ xem nhiều nhất";
            break;
        }
		case 2: {
            cell.textLabel.text = @"HayLam.vn";
            cell.detailTextLabel.text = @"Ảnh chế, clip hot, phim hay";
            break;
        }

		//default: break;
	}
    return cell;
	
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (![self connected]) {
        // not connected
        [self alertMessage:msgConnectionError];
        NSLog(msgConnectionError);
        return;
    }
    //
    self.indexPath=indexPath;
	// Browser
	NSMutableArray *photos = [[NSMutableArray alloc] init];
	NSMutableArray *thumbs = [[NSMutableArray alloc] init];
    MWPhoto *photo;
    BOOL displayActionButton = YES;
    BOOL displaySelectionButtons = NO;
    BOOL displayNavArrows = YES;
    BOOL enableGrid = YES;
    BOOL startOnGrid = YES;
    
    // caothetoan
    // convert to JSON
    NSError *myError = nil;
    self.pageIndex=0;
    
    NSURL *urlReq;
    
	switch (indexPath.row) {
		case 0:{
            
            self.orderby =@"new";
           
            self.categoryId = 1;
                      urlReq = [HayLamHelper buildURLWithParameters:self.categoryId :self.pageIndex :self.pageSize :self.orderby ];
            
			break;
        }
		case 1: {
            self.orderby =@"hot";
            self.categoryId = 2;
          
            urlReq = [HayLamHelper buildURLWithParameters:self.categoryId :self.pageIndex :self.pageSize :self.orderby ];
            
            //startOnGrid = YES;
			break;
        }
        case 2: {
            //urlReq =[NSURL URLWithString:@"http://haylam.vn/ActionHandler.ashx?currentPage=0&pageSize=100&userId=&orderBy=new&ActionObject=examination&action=getListImageByPage"];
           self.categoryId = 1;
            NSString *URLString =     [NSString stringWithFormat:@"%@?ActionObject=examination&action=getListImageByPage&categoryId=%d&currentPage=%d&pageSize=%d&orderBy=%@", hayLamDataURL, self.categoryId, self.pageIndex, self.pageSize, self.orderby ];
            
            urlReq =[NSURL URLWithString:URLString];
            startOnGrid = NO;
			break;
        }
		/*
		case 7: {
            @synchronized(_assets) {
                NSMutableArray *copy = [_assets copy];
                for (ALAsset *asset in copy) {
                    [photos addObject:[MWPhoto photoWithURL:asset.defaultRepresentation.url]];
                    [thumbs addObject:[MWPhoto photoWithImage:[UIImage imageWithCGImage:asset.thumbnail]]];
                }
            }
			break;
        }
		default: break;*/
	}
    
    NSData *data = [HayLamHelper fetchResponseWithURL:urlReq];
    //NSString *string = [HayLamPhoto stringByRemovingFlickrJavaScript:data];
    
    if(data== nil){
        [self alertMessage:@"Không lấy được dữ liệu từ máy chủ. Vui lòng thử lại"];
        return;
    }
    unsigned long responseDataLength = (unsigned long)[data length];
    if(responseDataLength <= 0)
    {
        // alert message
        [self alertMessage:@"Không lấy được dữ liệu từ máy chủ. Vui lòng thử lại"];
        return;
    }
    NSDictionary *res = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&myError];
    
    //NSDictionary *res =  [HayLamPhoto photoGetListWithParam:categoryId :pageIndex :pageSize: orderby];
    if(res== nil){
        [self alertMessage:@"Không xử lý được dữ liệu từ máy chủ. Vui lòng thử lại"];
        return;
    }
    
    
    NSLog(@"Count %lu", (unsigned long)res.count);
    self.pageTotal = 5;
    
    self.responseData = [NSMutableData data];
    
    
    //
    
    for (NSDictionary *result in res) {
        NSString *src = [result objectForKey:@"ImageSrc"];
        //NSLog(@"ImageSrc: %@", src);
        NSString *desc = [result objectForKey:@"Description"];
        
        photo = [MWPhoto photoWithURL:[NSURL URLWithString:src]];
        photo.caption = desc;
        [photos addObject:photo];
        [thumbs addObject:[MWPhoto photoWithURL:[NSURL URLWithString:src]]];
        
        //[haylamPhotoArray addObject:haylamPhoto];
    }
    self.photos = photos;
    self.thumbs = thumbs;
	
	// Create browser
	//MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
    self.mwPhotoBrowser =  [[MWPhotoBrowser alloc] initWithDelegate:self];
    
    self.mwPhotoBrowser.displayActionButton = displayActionButton;
    self.mwPhotoBrowser.displayNavArrows = displayNavArrows;
    self.mwPhotoBrowser.displaySelectionButtons = displaySelectionButtons;
    self.mwPhotoBrowser.alwaysShowControls = displaySelectionButtons;
    self.mwPhotoBrowser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    self.mwPhotoBrowser.wantsFullScreenLayout = YES;
#endif
    self.mwPhotoBrowser.enableGrid = enableGrid;
    self.mwPhotoBrowser.startOnGrid = startOnGrid;
    self.mwPhotoBrowser.enableSwipeToDismiss = YES;
    [self.mwPhotoBrowser setCurrentPhotoIndex:0];
    
    // Reset selections
    if (displaySelectionButtons) {
        _selections = [NSMutableArray new];
        for (int i = 0; i < photos.count; i++) {
            [_selections addObject:[NSNumber numberWithBool:NO]];
        }
    }
    
    // Show
    if (_segmentedControl.selectedSegmentIndex == 0) {
        // Push
        [self.navigationController pushViewController:self.mwPhotoBrowser animated:YES];
    } else {
        // Modal
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:self.mwPhotoBrowser];
        nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:nc animated:YES completion:nil];
    }
    
    // Release
	
	// Deselect
	[self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // Test reloading of data after delay
    //double delayInSeconds = 3;
    //dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    //dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
    
//        // Test removing an object
//        [_photos removeLastObject];
//        [browser reloadData];
//    
//        // Test all new
//        [_photos removeAllObjects];
//        [_photos addObject:[MWPhoto photoWithFilePath:[[NSBundle mainBundle] pathForResource:@"photo3" ofType:@"jpg"]]];
//        [browser reloadData];
//    
//        // Test changing photo index
//        [browser setCurrentPhotoIndex:9];
    
//        // Test updating selections
//        _selections = [NSMutableArray new];
//        for (int i = 0; i < [self numberOfPhotosInPhotoBrowser:browser]; i++) {
//            [_selections addObject:[NSNumber numberWithBool:YES]];
//        }
//        [browser reloadData];
        
    //});//comment

}

#pragma mark - MWPhotoBrowserDelegate

- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser {
    return _photos.count;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index {
    if (index < _photos.count)
        return [_photos objectAtIndex:index];
    return nil;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser thumbPhotoAtIndex:(NSUInteger)index {
    if (index < _thumbs.count)
        return [_thumbs objectAtIndex:index];
    return nil;
}

//- (MWCaptionView *)photoBrowser:(MWPhotoBrowser *)photoBrowser captionViewForPhotoAtIndex:(NSUInteger)index {
//    MWPhoto *photo = [self.photos objectAtIndex:index];
//    MWCaptionView *captionView = [[MWCaptionView alloc] initWithPhoto:photo];
//    return [captionView autorelease];
//}

//- (void)photoBrowser:(MWPhotoBrowser *)photoBrowser actionButtonPressedForPhotoAtIndex:(NSUInteger)index {
//    NSLog(@"ACTION!");
//}

- (void)photoBrowser:(MWPhotoBrowser *)photoBrowser didDisplayPhotoAtIndex:(NSUInteger)index {
    NSLog(@"Did start viewing photo at index %lu", (unsigned long)index);
    // if view last index of photo then get more next page
    if (index== _photos.count-1 && self.pageIndex < self.pageTotal)
    {
       
        NSLog( @"photo at the end of page %d. Load more",  self.pageIndex );
        
        if (![self connected]) {
            // not connected
            [self alertMessage:msgConnectionError];
            NSLog(msgConnectionError);
            return;
        }
        self.pageIndex++;
        
        // load more photo by caothetoan
        // Browser
      
        MWPhoto *photo;
     
        BOOL startOnGrid = NO;
        
        // caothetoan
        // convert to JSON
        NSError *myError = nil;
      
        NSURL *urlReq;
       
        switch (self.indexPath.row) {
            case 0:{
               
                urlReq = [HayLamHelper buildURLWithParameters:self.categoryId :self.pageIndex :hayLamPhotoPageSize :self.orderby ];
                
                break;
            }
            case 1: {
                
                urlReq = [HayLamHelper buildURLWithParameters:self.categoryId :self.pageIndex :hayLamPhotoPageSize :self.orderby ];
                
                //startOnGrid = YES;
                break;
            }
            case 2: {
                NSString *URLString =     [NSString stringWithFormat:@"%@?ActionObject=examination&action=getListImageByPage&categoryId=%d&currentPage=%d&pageSize=%d&orderBy=%@", hayLamDataURL, self.categoryId, self.pageIndex, hayLamPhotoPageSize, self.orderby ];
                
                urlReq =[NSURL URLWithString:URLString];
                startOnGrid = NO;
                break;
            }
             
        }
        
        NSData *data = [HayLamHelper fetchResponseWithURL:urlReq];
        //NSString *string = [HayLamPhoto stringByRemovingFlickrJavaScript:data];
        
        if(data== nil){
            [self alertMessage:@"Không lấy được dữ liệu từ máy chủ. Vui lòng thử lại"];
            return;
        }
        unsigned long responseDataLength = (unsigned long)[data length];
        if(responseDataLength <= 0)
        {
            // alert message
            [self alertMessage:@"Không lấy được dữ liệu từ máy chủ. Vui lòng thử lại"];
            return;
        }
        NSDictionary *res = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&myError];
        
        //NSDictionary *res =  [HayLamPhoto photoGetListWithParam:categoryId :pageIndex :pageSize: orderby];
        if(res== nil){
            [self alertMessage:@"Không xử lý được dữ liệu từ máy chủ. Vui lòng thử lại"];
            return;
        }
        
        
        NSLog(@"Count %lu", (unsigned long)res.count);
        
        
        self.responseData = [NSMutableData data];
        
        
        //
        
        for (NSDictionary *result in res) {
            NSString *src = [result objectForKey:@"ImageSrc"];
            //NSLog(@"ImageSrc: %@", src);
            NSString *desc = [result objectForKey:@"Description"];
            
            photo = [MWPhoto photoWithURL:[NSURL URLWithString:src]];
            photo.caption = desc;
            [self.photos  addObject:photo];
            [self.thumbs addObject:[MWPhoto photoWithURL:[NSURL URLWithString:src]]];
            
            //[haylamPhotoArray addObject:haylamPhoto];
        }
      
        [self.mwPhotoBrowser setCurrentPhotoIndex:index];
       
        [self.mwPhotoBrowser reloadData];
        
        // Deselect
        //[self.tableView deselectRowAtIndexPath:self.indexPath animated:YES];
    }
    
}

- (BOOL)photoBrowser:(MWPhotoBrowser *)photoBrowser isPhotoSelectedAtIndex:(NSUInteger)index {
    return [[_selections objectAtIndex:index] boolValue];
}

//- (NSString *)photoBrowser:(MWPhotoBrowser *)photoBrowser titleForPhotoAtIndex:(NSUInteger)index {
//    return [NSString stringWithFormat:@"Photo %lu", (unsigned long)index+1];
//}

- (void)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index selectedChanged:(BOOL)selected {
    [_selections replaceObjectAtIndex:index withObject:[NSNumber numberWithBool:selected]];
    NSLog(@"Photo at index %lu selected %@", (unsigned long)index, selected ? @"YES" : @"NO");
}

- (void)photoBrowserDidFinishModalPresentation:(MWPhotoBrowser *)photoBrowser {
    // If we subscribe to this method we must dismiss the view controller ourselves
    NSLog(@"Did finish modal presentation");
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Load Assets

- (void)loadAssets {
    
    // Initialise
    _assets = [NSMutableArray new];
    _assetLibrary = [[ALAssetsLibrary alloc] init];
    
    // Run in the background as it takes a while to get all assets from the library
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        NSMutableArray *assetGroups = [[NSMutableArray alloc] init];
        NSMutableArray *assetURLDictionaries = [[NSMutableArray alloc] init];
        
        // Process assets
        void (^assetEnumerator)(ALAsset *, NSUInteger, BOOL *) = ^(ALAsset *result, NSUInteger index, BOOL *stop) {
            if (result != nil) {
                if ([[result valueForProperty:ALAssetPropertyType] isEqualToString:ALAssetTypePhoto]) {
                    [assetURLDictionaries addObject:[result valueForProperty:ALAssetPropertyURLs]];
                    NSURL *url = result.defaultRepresentation.url;
                    [_assetLibrary assetForURL:url
                                   resultBlock:^(ALAsset *asset) {
                                       if (asset) {
                                           @synchronized(_assets) {
                                               [_assets addObject:asset];
                                               if (_assets.count == 1) {
                                                   // Added first asset so reload data
                                                   [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
                                               }
                                           }
                                       }
                                   }
                                  failureBlock:^(NSError *error){
                                      NSLog(@"operation was not successfull!");
                                  }];
                    
                }
            }
        };
        
        // Process groups
        void (^ assetGroupEnumerator) (ALAssetsGroup *, BOOL *) = ^(ALAssetsGroup *group, BOOL *stop) {
            if (group != nil) {
                [group enumerateAssetsWithOptions:NSEnumerationReverse usingBlock:assetEnumerator];
                [assetGroups addObject:group];
            }
        };
        
        // Process!
        [self.assetLibrary enumerateGroupsWithTypes:ALAssetsGroupAll
                                         usingBlock:assetGroupEnumerator
                                       failureBlock:^(NSError *error) {
                                           NSLog(@"There is an error");
                                       }];
        
    });
    
}

@end

