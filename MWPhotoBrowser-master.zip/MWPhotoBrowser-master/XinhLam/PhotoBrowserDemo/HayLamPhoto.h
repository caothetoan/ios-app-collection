//
//  HayLamPhoto.h
//  XinhLam
//
//  Created by Toan Cao on 8/23/14.
//
//

#import <Foundation/Foundation.h>

@interface HayLamPhoto : NSObject
{
    
}
@property (strong, nonatomic) NSString *Description;
@property (strong, nonatomic) NSString *ImageSrc;

@end