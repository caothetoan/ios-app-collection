//
//  DetailViewController.m
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/12/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import "DetailViewController.h"
#import "ServerCommunicator.h"
#import "RSSEntry.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(NSString *)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
            
        // Update the view.
        [self configureView];
    }
}

- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem) {
        
        self.textView.text = ((RSSEntry *)self.detailItem).articleTitle;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

- (void)viewDidDisappear:(BOOL)animated {
    if (self.audioPlayer) {
        if (self.audioPlayer.isPlaying) {
            [self.audioPlayer stop];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (IBAction)handleSpeak:(id)sender {
//    self.speakButton.enabled = false;
//    [self.activityIndicatorView startAnimating];
//    [self text2Speech:((RSSEntry *)self.detailItem).articleTitle];
//}

- (IBAction)handleSpeak:(id)sender {
    NSString *text = _textView.text;
    if([text length] == 0)
        return;
    self.speakButton.enabled = false;
    [self.activityIndicatorView startAnimating];
    [self text2Speech:text];
}

- (void) text2Speech : (NSString *) text {
    ServerCommunicator *serverCommunicator = [[ServerCommunicator alloc] init];
    [serverCommunicator text2SpeechData:text completion:^(NSData *speechData, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.activityIndicatorView stopAnimating];
        });
        if (error) {
            NSLog(@"Error: %@", error);
        } else {
            [self playSoundData:speechData];
        }
    }];
}

- (void) playSoundUrl : (NSURL *) soundUrl {
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc]
                        initWithContentsOfURL:soundUrl
                        error:&error];
    if (error) {
        NSLog(@"Error in audioPlayer: %@",
              [error localizedDescription]);
    } else {
        self.audioPlayer.delegate = self;
        [self.audioPlayer prepareToPlay];
        
        [self.audioPlayer play];
    }
}

- (void) playSoundData : (NSData *) soundData {
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc]
                        initWithData:soundData
                        error:&error];
    if (error) {
        NSLog(@"Error in audioPlayer: %@",
              [error localizedDescription]);
    } else {
        self.audioPlayer.delegate = self;
        [self.audioPlayer prepareToPlay];
        
        [self.audioPlayer play];
    }
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}


- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    NSLog(@"audioPlayerDidFinishPlaying");
    dispatch_async(dispatch_get_main_queue(), ^{
        self.speakButton.enabled = true;
    });
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError * __nullable)error {
    NSLog(@"audioPlayerDecodeErrorDidOccur");
    dispatch_async(dispatch_get_main_queue(), ^{
        self.speakButton.enabled = true;
    });
}

@end
