//
//  RSSReader.h
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/14/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RSSReader : NSObject

- (void) readRSSUrl : (NSURL *)rssUrl completion:(void (^)(NSArray *items, NSError *error))completion;

@end
