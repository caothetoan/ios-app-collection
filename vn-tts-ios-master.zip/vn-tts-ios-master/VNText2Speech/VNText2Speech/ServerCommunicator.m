//
//  ServerCommunicator.m
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/12/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import "ServerCommunicator.h"

@implementation ServerCommunicator

- (void) text2SpeechFile : (NSString *) text completion:(void (^)(NSURL *speechFile, NSError *error))completion {
    NSURLRequest *request = [self buildRequest4Text:text];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDownloadTask *downloadTask = [session downloadTaskWithRequest:request
                                                            completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                                                                if (error) {
                                                                    completion(nil, error);
                                                                } else {
                                                                    NSURL *newLocation = [self renameFile2Mp3:location];
                                                                    completion(newLocation, nil);
                                                                }
                                              }];
    
    [downloadTask resume];
}

- (NSURLRequest *) buildRequest4Text : (NSString *) text {
    NSLog(@"Speech for text: %@", text);
    NSString *correctText = [text stringByReplacingOccurrencesOfString:@"\"" withString:@"\'"];
    correctText = [NSString stringWithFormat:@"\"%@\"", correctText];
	NSDictionary *headers = @{ @"content-type": @"application/json",\
								// dùng token của bạn để khai báo cho api_key
                               @"api_key": @"" };
    NSData *postData = [correctText dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://api.openfpt.vn/text2speech"]
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:30.0];
    [request setHTTPMethod:@"POST"];
    [request setAllHTTPHeaderFields:headers];
    [request setHTTPBody:postData];
    
    return request;
}

- (NSURL *) renameFile2Mp3: (NSURL *) location {
    NSData *fileData = [NSData dataWithContentsOfURL:location];
    NSString *newFile = [NSTemporaryDirectory() stringByAppendingPathComponent:@"temp.mp3"];
    
    NSURL *destinationUrl = [NSURL fileURLWithPath:newFile];
    [fileData writeToURL:destinationUrl atomically:NO];
    return destinationUrl;
}

- (void) text2SpeechData : (NSString *) text completion:(void (^)(NSData *speechData, NSError *error))completion {
    NSURLRequest *request = [self buildRequest4Text:text];
    
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                        if (error) {
                                                            NSLog(@"%@", error);
                                                            completion(nil, error);
                                                        } else {
                                                            completion(data, nil);
                                                        }
                                                    }];
    [dataTask resume];
}

@end
