//
//  RSSReader.m
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/14/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import "RSSReader.h"
#import "GDataXMLNode.h"
#import "GDataXMLElement-Extras.h"
#import "RSSEntry.h"
#import "NSDate+InternetDateTime.h"

@implementation RSSReader
{
    void (^_completion)(NSArray *items, NSError *error);
}

- (void) readRSSUrl : (NSURL *)rssUrl completion:(void (^)(NSArray *items, NSError *error))completion {
    _completion = completion;
    
    NSURLRequest *request = [NSURLRequest requestWithURL:rssUrl];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                    if (error) {
                                                        NSLog(@"%@", error);
                                                        _completion(nil, error);
                                                    } else {
                                                        [self parseRSSXmlData:data];
                                                    }
                                                }];
    [dataTask resume];
}

- (void) parseRSSXmlData: (NSData *)rssXMLData {
    NSError *error;
    GDataXMLDocument *doc = [[GDataXMLDocument alloc] initWithData:rssXMLData
                                                           options:0 error:&error];
    if (doc == nil) {
        NSLog(@"Failed to parse XML data");
        NSLog(@"Error: %@", error);
        _completion(nil, error);
    } else {
        
        NSMutableArray *entries = [NSMutableArray array];
        [self parseFeed:doc.rootElement entries:entries];
        _completion(entries, nil);
    }
}

- (void)parseFeed:(GDataXMLElement *)rootElement entries:(NSMutableArray *)entries {
    if ([rootElement.name compare:@"rss"] == NSOrderedSame) {
        [self parseRss:rootElement entries:entries];
    } else if ([rootElement.name compare:@"feed"] == NSOrderedSame) {
        [self parseAtom:rootElement entries:entries];
    } else {
        NSLog(@"Unsupported root element: %@", rootElement.name);
    }
}

- (void)parseRss:(GDataXMLElement *)rootElement entries:(NSMutableArray *)entries {
    
    NSArray *channels = [rootElement elementsForName:@"channel"];
    for (GDataXMLElement *channel in channels) {
        
        NSString *blogTitle = [channel valueForChild:@"title"];
        
        NSArray *items = [channel elementsForName:@"item"];
        for (GDataXMLElement *item in items) {
            
            NSString *articleTitle = [item valueForChild:@"title"];
            NSString *articleUrl = [item valueForChild:@"link"];
            NSString *articleDateString = [item valueForChild:@"pubDate"];
            NSDate *articleDate = [NSDate dateFromInternetDateTimeString:articleDateString formatHint:DateFormatHintRFC822];
            
            RSSEntry *entry = [[RSSEntry alloc] initWithBlogTitle:blogTitle
                                                      articleTitle:articleTitle
                                                        articleUrl:articleUrl
                                                       articleDate:articleDate];
            [entries addObject:entry];
            
        }
    }
    
}

- (void)parseAtom:(GDataXMLElement *)rootElement entries:(NSMutableArray *)entries {
    
    NSString *blogTitle = [rootElement valueForChild:@"title"];
    
    NSArray *items = [rootElement elementsForName:@"entry"];
    for (GDataXMLElement *item in items) {
        
        NSString *articleTitle = [item valueForChild:@"title"];
        NSString *articleUrl = nil;
        NSArray *links = [item elementsForName:@"link"];
        for(GDataXMLElement *link in links) {
            NSString *rel = [[link attributeForName:@"rel"] stringValue];
            NSString *type = [[link attributeForName:@"type"] stringValue];
            if ([rel compare:@"alternate"] == NSOrderedSame &&
                [type compare:@"text/html"] == NSOrderedSame) {
                articleUrl = [[link attributeForName:@"href"] stringValue];
            }
        }
        
        NSString *articleDateString = [item valueForChild:@"updated"];
        NSDate *articleDate = [NSDate dateFromInternetDateTimeString:articleDateString formatHint:DateFormatHintRFC3339];
        
        RSSEntry *entry = [[RSSEntry alloc] initWithBlogTitle:blogTitle
                                                  articleTitle:articleTitle
                                                    articleUrl:articleUrl
                                                   articleDate:articleDate];
        [entries addObject:entry];
        
    }      
    
}

@end
