//
//  ServerCommunicator.h
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/12/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServerCommunicator : NSObject

- (void) text2SpeechFile : (NSString *) text completion:(void (^)(NSURL *speechFile, NSError *error))completion;

- (void) text2SpeechData : (NSString *) text completion:(void (^)(NSData *speechData, NSError *error))completion;

@end
