//
//  MasterViewController.h
//  VNText2Speech
//
//  Created by Tuan Nguyen on 5/12/16.
//  Copyright © 2016 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;

@end

