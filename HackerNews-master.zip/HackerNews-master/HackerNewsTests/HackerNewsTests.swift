//
//  HackerNewsTests.swift
//  HackerNewsTests
//
//  Copyright (c) 2015 Amit Burstein. All rights reserved.
//  See LICENSE for licensing information.
//

import XCTest
@testable import HackerNews

class HackerNewsTests: XCTestCase {}
