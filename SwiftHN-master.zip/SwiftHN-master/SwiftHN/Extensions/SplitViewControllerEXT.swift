//
//  SplitViewControllerEXT.swift
//  SwiftHN
//
//  Created by Thomas Ricouard on 12/06/14.
//  Copyright (c) 2014 Thomas Ricouard. All rights reserved.
//

import UIKit

extension UISplitViewController {

}
